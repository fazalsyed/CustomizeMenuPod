//
//  ViewController.swift
//  ThingsUI
//
//  Created by Ryan Nystrom on 3/7/18.
//  Copyright © 2018 Ryan Nystrom. All rights reserved.
//

import UIKit
import ContextMenu

class ViewController: UIViewController, MenuViewControllerDelegate, ContextMenuDelegate {
    
    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        button.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(onPan(gesture:))))
    }
    
    @objc func onPan(gesture: UIPanGestureRecognizer) {
        guard gesture.state == .changed else { return }
        button.center = gesture.location(in: view)
    }
    
    @IBAction func onButton(_ sender: Any) {
        let menuVC = MenuViewController()
        menuVC.delegate = self
        ContextMenu.shared.show(
            sourceViewController: self,
            viewController: menuVC,
            options: ContextMenu.Options(
                containerStyle: ContextMenu.ContainerStyle(
                    backgroundColor: .white
                ),
                menuStyle: .minimal,
                hapticsStyle: .medium
            ),
            sourceView: button,
            delegate: self
        )
    }
    // MARK: ContextMenuDelegate
    func contextMenuWillDismiss(viewController: UIViewController, animated: Bool) {
        print("will dismiss")
    }
    
    func contextMenuDidDismiss(viewController: UIViewController, animated: Bool) {
        print("did dismiss")
    }
    
}

extension ViewController {
    func menuViewControllerDidSelectOption(_ menuViewController: MenuViewController, option: String) {
        switch option {
        case "Test1":
            let vc1 = storyboard?.instantiateViewController(withIdentifier: "TestVC") as! TestVC
            navigationController?.pushViewController(vc1, animated: true)
        case "Test2":
            let vc2 = storyboard?.instantiateViewController(withIdentifier: "TestTwoVC") as! TestTwoVC
            navigationController?.pushViewController(vc2, animated: true)
        case "Test3":
            let vc3 = storyboard?.instantiateViewController(withIdentifier: "TestVC") as! TestVC
            navigationController?.pushViewController(vc3, animated: true)
        case "Test4":
            let vc4 = storyboard?.instantiateViewController(withIdentifier: "TestTwoVC") as! TestTwoVC
            navigationController?.pushViewController(vc4, animated: true)
        case "Test5", "Test6":
            showAlertForOptionFiveAndSix()
        default:
            break
        }
        menuViewController.dismiss(animated: true, completion: nil)
    }
    
    private func showAlertForOptionFiveAndSix() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Functionality Not Implemented", message: "You selected Test5 or Test6", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
}

