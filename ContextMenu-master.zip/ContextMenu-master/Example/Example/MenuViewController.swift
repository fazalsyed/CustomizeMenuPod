//
//  MenuViewController.swift
//  ThingsUI
//
//  Created by Ryan Nystrom on 3/8/18.
//  Copyright © 2018 Ryan Nystrom. All rights reserved.
//
import UIKit

protocol MenuViewControllerDelegate: class {
    func menuViewControllerDidSelectOption(_ menuViewController: MenuViewController, option: String)
}
class MenuViewController: UITableViewController {
    let arrMenu = ["Test1","Test2","Test3","Test4","Test5","Test6"]
    let cellHeight: CGFloat = 60
    var totalHeight: CGFloat = 0
    weak var delegate: MenuViewControllerDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        tableSetup()
    }
    //MARK: Func For TableView Setup()
    func tableSetup(){
        LoadXib()
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        tableView.sectionHeaderHeight = 35
        tableView.sectionFooterHeight = 35
        CustomtableHeight()
        tableView.contentInset.top = -25
        tableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: CGFloat.leastNonzeroMagnitude))
    }
    //MARK: Func For LoadXib()
    func LoadXib(){
        tableView.register(UINib(nibName: "CellT_MenuList", bundle: nil), forCellReuseIdentifier: "CellT_MenuList")
    }
    //MARK: Func For Dynamic Height().
    func CustomtableHeight() {
        tableView.reloadData()
        tableView.layoutIfNeeded()
        let totalCellHeight = CGFloat(arrMenu.count) * cellHeight
        let totalHeaderHeight = CGFloat(tableView.numberOfSections) * tableView.sectionHeaderHeight
        let totalFooterHeight = CGFloat(tableView.numberOfSections) * tableView.sectionFooterHeight
        print("Total Cell Height:", totalCellHeight)
        print("Total Header Height:", totalHeaderHeight)
        print("Total Footer Height:", totalFooterHeight)
        totalHeight = totalCellHeight + totalHeaderHeight + totalFooterHeight
        preferredContentSize = CGSize(width: 240, height: totalHeight)
    }
    //MARK: TableViewDataSource And TableViewDelegate
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenu.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellT_MenuList", for: indexPath) as! CellT_MenuList
        let data = arrMenu[indexPath.row]
        cell.lbl_Menu.text = data
        cell.backgroundColor = .clear
        cell.lbl_Menu.textColor = UIColor.black
        let lastRowIndex = tableView.numberOfRows(inSection: 0) - 1
        if indexPath.row == lastRowIndex {
            cell.lbl_Menu.textColor = UIColor.red
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
    }
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 35
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 0))
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 0))
        return footerView
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedOption = arrMenu[indexPath.row]
        delegate?.menuViewControllerDidSelectOption(self, option: selectedOption)
    }
}
