//
//  CellT_MenuList.swift
//  Example
//
//  Created by syed fazal abbas on 21/04/24.
//  Copyright © 2024 Ryan Nystrom. All rights reserved.
//

import UIKit

class CellT_MenuList: UITableViewCell {

    @IBOutlet weak var lbl_Menu: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
